export interface Smestaj{
    id: number,
    naziv: string,
    mesto: string,
    ocena: number,
    cena: number,
    slika?: string
}